# CHANGELOG.md

## [3.0.0] - 2024-07-05

- Mosaic Redesign

## [2.2.0] - 2024-01-05

- Upgrade to Laravel 10, Jetstream 4 and Livewire 3

## [2.1.0] - 2023-06-23

- Account settings page fixes

## [2.0.0] - 2023-06-01

- Dark version added

## [1.0.3] - 2023-04-11

- Update dependencies

## [1.0.2] - 2023-02-13

- Update dependencies
- Improve sidebar icons color logic

## [1.0.0] - 2022-07-20

First release