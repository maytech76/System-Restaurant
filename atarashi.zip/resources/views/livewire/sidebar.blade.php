<div>
    @livewire('Sidebar', ['companies' => $companies]) 
            
    <!-- Logo -->
     @foreach ($companies as $company)
        <a class="block" href="{{ route('dashboard') }}">
            <img src="{{ asset('storage/' . $company->image_path) }}" alt="Logo de {{ $company->name }}"> 
        </a>
    @endforeach 
</div>
