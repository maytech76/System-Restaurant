<div>
    <div>
        
        <div class="flex justify-center shadow-md w-full h-[150px] my-6 rounded-lg gap-4 overflow-x-auto">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="gap-2 text-center flex-shrink-0">
                    <a href="#" wire:click.prevent="setCategory(<?php echo e($category->id); ?>)" class="">
                        <img src="<?php echo e($category->image_path ? asset('storage/' . $category->image_path) : asset('storage/categories/default.png')); ?>"
                             class="w-20 sm:w-[60px] sm:h-[80px] object-cover rounded-full border-2 border-red-700 border-solid">
                        <p class="text-gray-300"><?php echo e($category->name); ?></p>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    
        
        <div class="mt-10">
            <div>
                <div class='p-1'>
                    <h4 class="text-gray-200 font-semibold uppercase"><?php echo e($categories->find($selectedCategory)->name); ?></h4>
                    <ul class='grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 md:p-2 xl:p-4'>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class='relative bg-gradient-to-b from-gray-700 to-gray-900 flex w-full gap-4 border border-orange-700 rounded hover:transition shadow-md hover:border-red-900 hover:shadow-red-800'>
                                <Link class='w-full overflow-hidden rounded' href="<?php echo e(route('products.show', $product->id)); ?>">
                                    <img src="<?php echo e($product->image_path ? asset('storage/' . $product->image_path) : asset('default.jpg')); ?>" alt="<?php echo e($product->name); ?>" class='object-cover rounded w-28 h-full' />
                                </Link>
                                <div class='flex flex-col justify-between flex-grow gap-3 px-2'>
                                    <div class='w-full mt-2'>
                                        <span class='font-semibold md:text-xl text-yellow-600'><?php echo e($product->name); ?></span>
                                        <p class='pt-1 text-sm text-gray-300'><?php echo e($product->description ?? 'Descripción no disponible.'); ?></p>
                                    </div>
                                    <div class='flex items-center justify-between gap-1 mb-2'>
                                        <div class='text-sm text-gray-400'>
                                            <div class="flex items-center gap-1 text-white">
                                                
                                            </div>
                                        </div>
                                        <div class='flex items-center gap-1 px-2 py-1 text-gray-700 rounded'>
                                            <div class='text-md text-red-500'><?php echo e(number_format($product->price, 0, ',', '.')); ?> CLP</div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php /**PATH C:\laragon\www\atarashi\resources\views/livewire/category-products.blade.php ENDPATH**/ ?>