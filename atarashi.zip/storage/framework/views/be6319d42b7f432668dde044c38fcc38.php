<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 sm:px-6 lg:px-4 py-8 w-full max-w-9xl mx-auto">

        <!-- Dashboard actions -->
        <div class="sm:flex sm:justify-between sm:items-center mb-4 px-2 lg:px-4 w-full max-w-9xl mx-auto">
            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h3 class="text-xl md:text-xl text-gray-700 dark:text-gray-100 font-bold">Ficha Técnica Vehiculo</h3>
            </div>
            <!-- Right: Actions -->
            <div class="grid grid-flow-col sm:auto-cols-max justify-start sm:justify-end gap-2">
                <?php if (isset($component)) { $__componentOriginal2686ed4927c64f67d2844e9b73af898c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2686ed4927c64f67d2844e9b73af898c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.datepicker','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2686ed4927c64f67d2844e9b73af898c)): ?>
<?php $attributes = $__attributesOriginal2686ed4927c64f67d2844e9b73af898c; ?>
<?php unset($__attributesOriginal2686ed4927c64f67d2844e9b73af898c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2686ed4927c64f67d2844e9b73af898c)): ?>
<?php $component = $__componentOriginal2686ed4927c64f67d2844e9b73af898c; ?>
<?php unset($__componentOriginal2686ed4927c64f67d2844e9b73af898c); ?>
<?php endif; ?>
            </div>
        </div>

        <div class="flex items-center justify-center px-2 sm:px-4 lg:px-4 py-2 w-full max-w-9xl mx-auto">

                <div
                    class="w-full max-w-6xl p-4 bg-white border border-gray-200 rounded-lg shadow sm:p-6 md:p-8 dark:bg-gray-800 dark:border-gray-700">

                    
                    <div class="w-full text-center mb-8 text-xl md:text-xl text-gray-700 dark:text-gray-100 font-bold">
                        <h3 class="mb-4">Datos del Vehiculo</h3>
                        <hr>
                    </div>

                    <form action="<?php echo e(route('cars.update', $car->id)); ?>" method="POST" enctype="multipart/form-data">

                        <?php echo csrf_field(); ?>
                          <?php echo method_field('PUT'); ?>

                    <div class="sx:flex-wrap sm:flex gap-6">

                        
                        <div x-data="{ imagePreview: '<?php echo e($car->image_path ? asset('storage/' . $car->image_path) : ''); ?>' }" >

                                <!-- Vista previa de la imagen -->
                                <div class="mt-2">
                                    <template x-if="imagePreview">
                                        <img :src="imagePreview" alt="Vista previa de la imagen" class="justify-center items-center w-[300px] h-[250px] object-cover rounded-md shadow-sm">
                                    </template>
                                </div>

                                <label for="image" class="block text-sm font-medium text-gray-700">Imagen del Vehiculo</label>
                                <input type="file" name="image" id="image" class="mt-1 block w-100" accept="image/*"
                            @change="imagePreview = URL.createObjectURL($event.target.files[0])">
                    
                        </div>

                        <div class="ml-2 grid grid-cols-1 md:grid-cols-4 mb-8">
 

                            
                            <div class="mb-2 flex-wrap gap-2 pr-4">
                                <span class="text-[15px] font-bold text-gray-900 dark:text-white">Tipo de Vehiculo:
                                </span>
                                <select name="cartype_id"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-[180px] p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                    <option>Selecionar..</option>

                                    <?php $__currentLoopData = $cartypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"
                                            <?php echo e($car->cartype_id == $type->id ? 'selected' : ''); ?>>
                                            <?php echo e($type->name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>


                            
                            <div class="mb-2 flex-wrap gap-2 pr-6">
                                <span class="text-[15px] font-bold text-gray-900 dark:text-white">Marca del vehiculo:
                                </span>
                                <select name="brand_id"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                    <option>Selecionar..</option>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($brand->id); ?>"
                                            <?php echo e($car->brand_id == $brand->id ? 'selected' : ''); ?>>
                                            <?php echo e($brand->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            
                            <div class="mb-2 flex-wrap gap-2 pr-6">
                                <span class="text-[15px] font-bold text-gray-900 dark:text-white">Modelo del Vehiculo:
                                </span>
                                <select name="model_car_id"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                    <option>Selecionar..</option>

                                    <?php $__currentLoopData = $modelcars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($modelo->id); ?>"
                                            <?php echo e($car->model_car_id == $modelo->id ? 'selected' : ''); ?>>
                                            <?php echo e($modelo->name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                           

                            
                            <div class="mb-2 flex-wrap gap-2 pr-6">
                                <span class="text-[15px] font-bold text-gray-900 dark:text-white">Color de Carroceria
                                </span>
                                <input name="color"
                                    class="w-[180px] rounded-md border-gray-300 text-sm text-gray-500 dark:text-gray-400"
                                    value="<?php echo e($car->color); ?>">
                            </div>

                            
                            <div class="mb-2 flex-wrap gap-2 pr-6">
                                <span class="text-[15px] font-bold text-gray-900 dark:text-white">Cant- Pasajeros</span>
                                <input type="number" name="position" value="<?php echo e($car->position); ?>"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    required />
                            </div>

                            
                            <div class="mb-2 flex-wrap gap-2">
                                <span class="text-sm font-bold text-gray-900 dark:text-white">Placa Patente:</span>
                                <input type="text" value="<?php echo e($car->patent); ?>"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-[185px] p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    required readonly>
                            </div>


                            
                            <div class="mb-4 flex-wrap gap-2 pr-6">
                                <span class="text-[15px] font-bold text-gray-900 dark:text-white">Fecha de Fabricación:
                                </span>
                                <select name="year"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                    <option>Selecionar..</option>
                                    <option value=2022>2022</option>
                                    <option value=2023>2023</option>
                                    <option value=2024>2024</option>
                                    <option value=2025>2025</option>
                                    <option value=2026>2026</option>
                                </select>
                            </div>


                            
                            <div class="mb-2 flex-wrap gap-2 pr-6">
                                <span class="text-[15px] font-bold text-gray-900 dark:text-white">Tipo de
                                    Combustible:</span>
                                <select name="fuel_type"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-[180px] p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                    <option>Selecionar..</option>
                                    <option value="Gasolina">Gasolina</option>
                                    <option value="Diesel">Diesel</option>

                                </select>
                            </div>


                            
                            <div class="mb-2 flex-wrap gap-2 pr-6">
                                <span class="text-[15px] font-bold text-gray-900 dark:text-white">F-Mantenimiento:
                                </span>
                                <input type="date" name="maintenance" value="<?php echo e($car->maintenance); ?>"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    required placeholder="Ejemplo: XX-XX-XX" />
                            </div>


                            
                            <div class="mb-2 flex-wrap gap-2 pr-6">
                                <span class="text-[15px] font-bold text-gray-900 dark:text-white">Tipo de Tracción
                                </span>
                                <select name="traction"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                    <option>Selecionar..</option>
                                    <option value="4x2">4 x 2 (Trasera)</option>
                                    <option value="4x2">4 x 2 (Delantera)</option>
                                    <option value="4x4">4 x 4 (Trasera)</option>
                                    <option value="4x2">4 x 2 (Delantera)</option>

                                </select>
                            </div>


                            
                            <div class="mb-2 flex-wrap gap-2 pr-6">
                                <span class="text-[15px] font-bold text-gray-900 dark:text-white">Kilimetraje Actual:
                                </span>
                                <input type="number" name="klm_to_day" value="<?php echo e($car->klm_to_day); ?>"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    required />
                            </div>


                            
                            <div class="mb-2 flex-wrap gap-2">
                                <span class="text-[15px] font-bold text-gray-900 dark:text-white">Perm-Circulación:
                                </span>
                                
                                <input type="date" name="circulation_end" value="<?php echo e($car->circulation_end); ?>"
                                    class="w-[185px] bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    required />
                            </div>


                            
                            <div x-data="{ status: <?php echo e($car->status); ?> }" class="mb-2 flex-wrap gap-2 pr-6">
                                <span class="text-[15px] font-bold mb-8">
                                    Estado del Vehiculo:
                                </span>

                                <label class="inline-flex items-center cursor-pointer mt-2">
                                    <input type="hidden" name="status" value="0">

                                    <input name="status" type="checkbox" :checked="status == 1" :value="status" @click="status = status == 1 ? 0 : 1" class="sr-only peer">
                                    <div
                                        class="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:w-5 after:h-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600">
                                    </div>
                                    <span class="ms-3 text-sm font-medium"
                                        :class="status == 1 ? 'text-green-600' : 'text-gray-600'">
                                        Activo
                                    </span>
                                </label>
                            </div>


                        </div>

                    </div>

                    
                    <div class="w-full flex gap-6 text-center justify-center">
                        <a href="<?php echo e(route('cars.index')); ?>"
                            class="block w-[200px] text-center bg-blue-200 hover:bg-blue-700 text-green-900 hover:text-white cursor-pointer p-2 rounded-lg">
                            Cerrar
                        </a>

                        <button type="submit"
                            class="block w-[200px] text-center bg-yellow-200 hover:bg-yellow-700 text-yellow-900 hover:text-black cursor-pointer p-2 rounded-lg">
                            Editar
                        </button>
                    </div>


                </div>

            </form>

        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\laravel10\resources\views/cars/edit.blade.php ENDPATH**/ ?>