<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'btn bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700/60 hover:border-gray-300 dark:hover:border-gray-600 text-gray-800 dark:text-gray-300'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\laragon\www\laravel10\resources\views/components/secondary-button.blade.php ENDPATH**/ ?>