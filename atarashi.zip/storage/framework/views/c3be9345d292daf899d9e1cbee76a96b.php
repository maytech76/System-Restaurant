<div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Agregar a Comanda</h1>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <!-- Imagen del producto -->
        <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-48 object-cover" />

        <!-- Información del producto -->
        <div class="p-4">
            <h3 class="text-lg font-semibold"><?php echo e($product->name); ?></h3>
            <p class="text-sm text-gray-600"><?php echo e($product->description); ?></p>
            <p class="text-xl font-bold mt-2 text-gray-900">$<?php echo e(number_format($product->price, 2)); ?></p>
        </div>

        <!-- Botón para confirmar la acción de agregar a comanda -->
        <div class="p-4 bg-gray-100">
            <button 
                class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600"
                wire:click="addToCart"
            >
                Agregar a Comanda
            </button>
        </div>
    </div>

    <!-- Mensaje de éxito -->
    <?php if(session()->has('success')): ?>
        <div class="mt-4 text-green-500">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\atarashi\resources\views/livewire/products/add-to-cart.blade.php ENDPATH**/ ?>