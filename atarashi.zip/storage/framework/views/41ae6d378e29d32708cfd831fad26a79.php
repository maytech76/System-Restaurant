<div>
    <div class="container mx-auto p-4">
        <!-- Input de búsqueda -->
        <div class="mb-6">
            <input 
                type="text" 
                wire:model.live.500ms="search" 
                class="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Buscar productos por nombre..."
            />
        </div>
    
        <!-- Resultados de la búsqueda en una grid -->
        <!--[if BLOCK]><![endif]--><?php if($products->count()): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white shadow-md rounded-lg overflow-hidden">
                        <!-- Imagen del producto -->
                        <img 
                            src="<?php echo e(asset('storage/' . $product->image_path)); ?>" 
                            alt="<?php echo e($product->name); ?>" 
                            class="w-full h-48 object-cover"
                        />
    
                        <!-- Información del producto -->
                        <div class="p-4">
                            <h3 class="text-lg font-semibold"><?php echo e($product->name); ?></h3>
                            <p class="text-sm text-gray-600"><?php echo e($product->description); ?></p>
                            <p class="text-xl font-bold mt-2 text-gray-900">$<?php echo e(number_format($product->price, 2)); ?></p>
                        </div>
    
                        <!-- Footer con el botón de "Agregar a Comanda" -->
                        <div class="p-4 bg-gray-100">
                            <button 
                                class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600"
                                wire:click="addToCart(<?php echo e($product->id); ?>)"
                            >
                                Agregar a Comanda
                            </button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
    
            <!-- Paginación -->
            <div class="mt-6">
                <?php echo e($products->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center text-gray-500">
                No se encontraron productos.
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\laragon\www\atarashi\resources\views/livewire/product-search.blade.php ENDPATH**/ ?>