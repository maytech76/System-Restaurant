<div class="hidden sm:block">
    <div class="py-8">
        <div></div>
    </div>
</div>
<?php /**PATH C:\laragon\www\laravel10\resources\views/components/section-border.blade.php ENDPATH**/ ?>